

#!/bin/bash

# Change directory to WebODM
cd WebODM

# Start WebODM using webodm.sh script
./webodm.sh start

# Move back to the parent directory
cd ..

# Change directory to Downloads
cd Downloads

# Run the Python script process_images.py with the specified argument
#python3 ./process_images.py /home/hassan/Downloads/GoogleMaps

python3 ./process_images.py /home/hassan/Downloads/odm_mygla_dataset-master/images
